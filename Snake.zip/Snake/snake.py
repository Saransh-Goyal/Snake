import pygame
import random
import math

pygame.init()

# About screen
home_screen = pygame.display.set_mode((500, 500))
pygame.display.set_caption('Snake')
font_score = pygame.font.Font('freesansbold.ttf', 16)
score_X = 10
score_Y = 10
score = 0

def set_score(x, y):
    global  font_score
    score_render = font_score.render(f'Score: {score}', True, (255, 255, 255))
    home_screen.blit(score_render, (x,y))

def background():
    bg_image = pygame.image.load('grass.jpg').convert()
    home_screen.blit(bg_image, [0, 0])
    home_screen.blit(bg_image, [0, 200])

# About Snake
snake_x = 250
snake_y = 300
update_x = 0
update_y = 0
currentX = 15
currentY = 15
def snake_prop(snake_list, lenx, leny):
    for x, y in snake_list:
        pygame.draw.rect(home_screen, (255, 0, 0), [x, y, lenx, leny])

#about food
food_x = random.randint(0, 480)
food_y = random.randint(11, 480)
food_state = 'available'
def get_snake(x, y):
    pygame.draw.circle(home_screen, (0, 0, 255), (x, y), 5)
    #food_state = 'eat'

# Food Eaten
def check_food_eaten(foodx, foody, snakex, snakey):
    print(foodx, foody, snakex, snakey)
    if ((snakey in range(foody, foody+5) or foody in range(snakey, snakey + 15))) and\
            ((foodx in range(snakex, snakex+15) or snakex in range(foodx, foodx+5))):
        return True

snake_list = []
snake_length = 1

exit_flag = False

while not exit_flag:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit_flag = True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                update_x = -2
                update_y = 0
            if event.key == pygame.K_RIGHT:
                update_x = 2
                update_y = 0
            if event.key == pygame.K_UP:
                update_y = -2
                update_x = 0
            if event.key == pygame.K_DOWN:
                update_y = 2
                update_x = 0


    snake_x += update_x
    snake_y += update_y

    if snake_x <= 0:
        snake_x = 485
    if snake_x >= 486:
        snake_x = 0

    if snake_y <= 0:
        snake_y = 485
    if snake_y >= 486:
        snake_y = 0
    background()

    state = check_food_eaten(food_x, food_y, snake_x, snake_y)
    if state:
        food_x = random.randint(0, 480)
        food_y = random.randint(0, 400)
        score += 1
        get_snake(food_x, food_y)
        snake_length += 5

    head = []
    head.append(snake_x)
    head.append(snake_y)
    snake_list.append(head)

    if len(snake_list) > snake_length:
        del(snake_list[0])

    if head in snake_list[:-1]:
        exit_flag = True
    snake_prop(snake_list, currentX, currentY)
    get_snake(food_x, food_y)
    set_score(score_X, score_Y)
    pygame.display.update()
